### Hexlet tests and linter status:
[![Actions Status](https://github.com/SashaTolkodubova/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/SashaTolkodubova/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/e2dde9df24bfb9172ec6/maintainability)](https://codeclimate.com/github/SashaTolkodubova/python-project-49/maintainability)

https://asciinema.org/a/12C9kdSriUTqaqYoSOwBsgikj
https://asciinema.org/a/sTZWuOp3gZeJ7iyaNAda2kb51
https://asciinema.org/a/49LlQzZASEh2Jnu1XIobMFe0y